## 移动端音乐播放器

H5+js+Zepto.js

### 扫码进入

![image](https://github.com/sayid760/H5musicPlayer/blob/master/img/qr.png)
